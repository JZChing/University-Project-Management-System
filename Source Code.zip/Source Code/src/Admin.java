import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

// Admin class extending User
public class Admin extends User {
    // Constructor
    public Admin(String password, String fullname, String id, String intake, String role) {
        super(password, fullname, id, role);
    }
    
    public Admin(){
        
    }
    
    // Method to write data to file
    public void writeDataToFile(String file, List<String> userData){
        try (FileWriter writer = new FileWriter(file)) {
            for (String userInfo : userData) {
                writer.write(userInfo + "\n");
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while writing to the file: " + e.getMessage());
            
        }
    }
    
    // Method to read data from file
    public List<String> readDataFromFile(String file) {
        List<String> userDataInfo = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(file))) {
            while (scanner.hasNextLine()) {
                userDataInfo.add(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File not found: " + file);
            
        }
        return userDataInfo;
    }   
  
    // Method to check if role's ID is unique
    public boolean idAvailable(String file, String id){
        try {
            File dataFile = new File(file);
            Scanner scanner = new Scanner(dataFile);
            while (scanner.hasNextLine()) {
                String data = scanner.nextLine();
                String[] userData = data.split(", ");
                if (id.equals(userData[1].trim()))
                    return false; // ID already exists
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while checking username availability.");
           
        }
        return true; // Username is available
    }
    
    // Method to login user
    public boolean loginUser(String id, String password) {
        final String[] DATA_FILES = {"Studentdata.txt", "Lecturerdata.txt", "Admindata.txt", "PMdata.txt"};
        String fullnameInFile, idInFile, passwordInFile, intakeInFile = null, roleInFile, AdditionalRoleInFile = " ", AssessmentTypeInFile = null;
        
        // Iterate over each data file
        for (String dataFile: DATA_FILES){
            // Read user data from current file
            List<String> userAllData = readDataFromFile(dataFile);
            for (String data: userAllData){
                String[] userData = data.split(", ");
                int numColumns = userData.length;
                
                fullnameInFile = userData[0].trim();
                idInFile = userData[1].trim();
                passwordInFile = userData[2].trim();
                roleInFile = userData[3].trim();
                if ("lecturer".equals(roleInFile) && numColumns >= 6) {
                    AdditionalRoleInFile = userData[4].trim();
                    AssessmentTypeInFile = userData[5].trim();
                } else if ("student".equals(roleInFile) && numColumns >= 5){
                    intakeInFile = userData[4].trim();
                }
                    
                if (id.equals(idInFile) && password.equals(passwordInFile)) {
                    // Set Session data
                    Session.setFullname(fullnameInFile);
                    Session.setId(idInFile);
                    Session.setPassword(passwordInFile);
                    Session.setRole(roleInFile);
                    Session.setFile(dataFile);                             
                    Lecturer.setAdditionalRole(AdditionalRoleInFile);
                    Lecturer.setAssessmentType(AssessmentTypeInFile);
                    Student.setIntake(intakeInFile);

                    JOptionPane.showMessageDialog(null, "Successfully logged in!");
                    return true;
                }
            }
        }
        // If no user found, show error message
        JOptionPane.showMessageDialog(null, "Invalid login crudential!\nPlease try again!");
        return false;
    }
    
    // Method to validate password
    public boolean validPassword(String password) {
        boolean containsUppercase = false;
        boolean containsLowercase = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                containsUppercase = true;
            } else if (Character.isLowerCase(c)) {
                containsLowercase = true;
            }
        }
        if (!containsUppercase || !containsLowercase) {
            JOptionPane.showMessageDialog(null, "Password must contain at least one uppercase and one lowercase letter!");
            return false;
        }
        if (password.length() < 6 || password.length() > 12) {
            JOptionPane.showMessageDialog(null, "Password must be between 6 - 12 characters long!");
            return false;
        }
        if (password.matches(".*[\\W_].*") || password.contains(" ")) {
            JOptionPane.showMessageDialog(null, "Password cannot contain symbols or spaces!");
            return false;
        }
        return true;
    }
    
    // Method to validate each field is not empty and ID is valid
    public boolean validateInputs(String fieldOne, String fieldTwo, String fieldThree) {
        if (fieldOne.isEmpty() || fieldTwo.isEmpty() || fieldThree.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in all fields!");
            return false;
        }
        return true;
    }

    // Method to validate id     
    public boolean validId(String id, String pattern, String format){
        if (!id.matches(pattern)) {
            JOptionPane.showMessageDialog(null, "Invalid ID format! It must follow the format " + format + " !");
            return false;
        }
        return true;
    } 
    
    // Method to toggle password visibility
    public void togglePasswordVisibility(JPasswordField passwordField, JToggleButton showPassword) {
        if (showPassword.isSelected()) {
            passwordField.setEchoChar((char) 0); // Show the password
            showPassword.setText("Hide");
        } else {
            passwordField.setEchoChar('*'); // Hide the password
            showPassword.setText("Show");
        }
    }
    
    // Method to add new student
    public boolean addNewStudent(String fullname, String id, String password, String intake, String confirmPassword) {
        // Validate all fields are entered
        if (!validateInputs(fullname, id, password)){
            return false;
        }
        
        // Validate new ID 
        if (!validId(id, "TP\\d{6}", "TPXXXXXX")) {
            return false;
        }
        
        // Check if student ID is used
        if (!idAvailable("Studentdata.txt", id)) {
            JOptionPane.showMessageDialog(null, "ID already exists! Please assign a different ID!");
            return false;
        }
        
        // Validate password
        if (!validPassword(password)) {
            return false;
        }
        
        // Check whether new and confirmation password matches
        if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(null, "Passwords do not match!");
        return false;
        }

        // Add new data back to file
        try (FileWriter addNew = new FileWriter("Studentdata.txt", true)){
            addNew.write(fullname + ", " + id + ", " + password + ", " + "student" + ", " + intake);
            addNew.write("\n"); // Ensure new content starts on a new line
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            
        }
        JOptionPane.showMessageDialog(null, "New student registered successfully!"); 
        return true;
    }
    
    // Method to add new lecturer
    public boolean addNewLecturer(String fullname, String id, String password, String confirmPassword) {
        // Validate all fields are entered
        if (!validateInputs(fullname, id, password)){
            return false;
        }
        
        // Validate new ID 
        if (!validId(id, "LR\\d{6}", "LRXXXXXX")) {
            return false;
        }
        
        // Check if lecturer ID is used
        if (!idAvailable("Lecturerdata.txt", id)) {
            JOptionPane.showMessageDialog(null, "ID already exists! Please assign a different ID!");
            return false;
        }
        
        // Validate password
        if (!validPassword(password)) {
            return false;
        }
          
        // Check whether new and confirmation password matches
        if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(null, "Passwords do not match!");
        return false;
        }

        // Add new data back to file
        try (FileWriter addNew = new FileWriter("Lecturerdata.txt", true)){
            addNew.write(fullname + ", " + id + ", " + password + ", " + "lecturer" + ", " + " " + ", " + " ");
            addNew.write("\n"); // Ensure new content starts on a new line
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        JOptionPane.showMessageDialog(null, "New lecturer registered successfully!"); 
        return true;
    }
    
    // Method to add new admin
    public boolean addNewAdmin(String fullname, String id, String password, String confirmPassword) {
        // Validate all fields are entered
        if (!validateInputs(fullname, id, password)){
            return false;
        }
        
        // Validate new ID 
        if (!validId(id, "AM\\d{6}", "AMXXXXXX")) {
            return false;
        }
        
        // Check if admin ID is used
        if (!idAvailable("Admindata.txt", id)) {
            JOptionPane.showMessageDialog(null, "ID already exists! Please assign a different ID!");
            return false;
        }
        
        // Validate password
        if (!validPassword(password)) {
            return false;
        }
          
        // Check whether new and confirmation password matches
        if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(null, "Passwords do not match!");
        return false;
        }
        
        // Set the admin data
        setFullname(fullname);
        setId(id);
        setPassword(password);
        setRole("admin");

        // Add new data back to file
        try (FileWriter addNew = new FileWriter("Admindata.txt", true)){
            addNew.write(fullname + ", " + id + ", " + password + ", " + "admin");
            addNew.write("\n"); // Ensure new content starts on a new line
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        JOptionPane.showMessageDialog(null, "New admin registered successfully!"); 
        return true;
    }
    
    // Method to change password
    public boolean changePassword(String currentPassword, String oldPassword, String newPassword, String confirmPassword, String currentFile, String currentId) {
       // Validate all fields are entered
        if (!validateInputs(oldPassword, newPassword, confirmPassword)){
            return false;
        }
        
        // Check whether current and old password matches
        if (!currentPassword.equals(oldPassword)) {
            JOptionPane.showMessageDialog(null, "Incorrect old password entered!");
            return false;
        }
              
        // Check whether new and confirmation password matches
        if (!newPassword.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(null, "New and Confirm passwords do not match!");
            return false;
        }
        
        // Validate password
        if (!validPassword(newPassword)) {
            return false;
        }
        
        // Read users data from the file
        List<String> userDataLines = readDataFromFile(currentFile);
        
        // Find and update the password for the current user
        List<String> updatedUserData = new ArrayList<>();
        for (String userDataLine : userDataLines) {
            String[] userData = userDataLine.split(", ");
            String Id = userData[1].trim();
            String password = userData[2].trim();
            if (Id.equals(currentId) && password.equals(currentPassword)) {
                userData[3] = newPassword;
            }
            updatedUserData.add(String.join(", ", userData));
        }
        
        // Rewrite the modified user data back to the file
        writeDataToFile(currentFile, updatedUserData);
        JOptionPane.showMessageDialog(null, "New password updated successfully");
        return true;
    }
    
    // Method to dispay user information to profile menu
    public void ViewProfile(JTextField fullnameText, JTextField idText, JTextField passwordText, JTextField roleText) {
        String Fullname = Session.getFullname();
        String Id = Session.getId();
        String Password = Session.getPassword();
        String Role = Session.getRole();
        
        fullnameText.setText(Fullname);
        idText.setText(Id);
        passwordText.setText(Password);
        roleText.setText(Role);
    }
    
    // Method to remove a user
    public boolean removeUser(String fileName, String userToDelete) {
        // Check if a user is selected
        if (userToDelete == null) {
            JOptionPane.showMessageDialog(null, "Please select a user to remove.");
            return false;
        }

        List<String> userList = new ArrayList<>();
        try {
            File file = new File(fileName);
            try (Scanner scanner = new Scanner(file)) {
                while (scanner.hasNextLine()) {
                    String data = scanner.nextLine();
                    String[] userData = data.split(", ");
                    
                    // Exclude the data for the user to be deleted
                    if (!(userData[1].equals(userToDelete))) {
                        userList.add(data);   
                    }
                }
            }
            
            // Write back to the file
            writeDataToFile(fileName, userList);
            JOptionPane.showMessageDialog(null, "User removed successfully");
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "File not found");
            
        } 
        return true;
    }
    
    // Method to convert a lecturer to a project manager
    public boolean assignPM(String lecturerID, String newId) {
        // Check if a user is selected
        if (lecturerID == null) {
            JOptionPane.showMessageDialog(null, "Please select a user to assign.");
            return false;
        }
                
        // Validate new ID 
        if (!validId(newId, "PM\\d{6}", "PMXXXXXX")) {
            return false;
        }
        
        // Check if project manager ID is used
        if (!idAvailable("PMdata.txt", newId)) {
            JOptionPane.showMessageDialog(null, "ID already exists! Please assign a different ID!");
            return false;
        }
        
        List<String> lecturerData = readDataFromFile("Lecturerdata.txt");
        List<String> updatedLecturerData = new ArrayList<>();
        List<String> pmData = readDataFromFile("PMdata.txt");

        boolean found = false;
        for (String data : lecturerData) {
            String[] userData = data.split(", ");
            if (userData[1].equals(lecturerID)) {
                // Update the ID and role for the new project manager
                String newLine = userData[0] + ", " + newId + ", " + userData[2] + ", project manager";
                pmData.add(newLine);
                found = true;
            } else {
                updatedLecturerData.add(data);
            }
        }

        if (found) {
            writeDataToFile("Lecturerdata.txt", updatedLecturerData);
            writeDataToFile("PMdata.txt", pmData);
            JOptionPane.showMessageDialog(null, "Lecturer switched to Project Manager successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Lecturer not found: " + lecturerID);
        }
        return true;
    }
}
