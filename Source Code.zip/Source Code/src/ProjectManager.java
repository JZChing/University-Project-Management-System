
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ProjectManager extends User {
    // Constructor
    public ProjectManager(String password, String fullname, String id, String intake, String role) {
        super(password, fullname, id, role);
    }
    
    public ProjectManager(){
        
    }
    
    //method to assign supervisor and second markers to lecturer 
    public static void assign_supervisor(String lecturerID, String project) {
        try {
            // Read the contents of Lecturerdata.txt
            File file = new File("Lecturerdata.txt");
            StringBuilder stringBuilder;
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                stringBuilder = new StringBuilder();
                String line;
                // Search for the lecturer ID and update the line if found
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(", ");
                    if (parts.length >= 2 && parts[1].equals(lecturerID)) {
                        // Update the line with the new role and project
                        parts[4] = "supervisor";
                        parts[5] = project;
                        line = String.join(", ", parts);
                    }
                    stringBuilder.append(line).append(System.lineSeparator());
                }
            }

            try ( // Write the updated contents back to Lecturerdata.txt
                BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(stringBuilder.toString());
            }

            JOptionPane.showMessageDialog(null, "Supervisor assigned successfully.");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProjectManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ProjectManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //method to ssign supervisor and sencond markers to lecturer 
    public static void assign_secondmarker(String studentID, String lecturerID, String project){
        try {
            String lecturerName = null;
            // Read the contents of Lecturerdata.txt
            File file = new File("Lecturerdata.txt");
            StringBuilder stringBuilder;
            
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                stringBuilder = new StringBuilder();
                String line;
                // Search for the lecturer ID and update the line if found
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(", ");
                    if (parts.length >= 2 && parts[1].equals(lecturerID)) {
                        // Update the line with the new role and project
                        
                        
                        lecturerName = parts[0];
                    }
                    stringBuilder.append(line).append(System.lineSeparator());
                }
            }

            try ( // Write the updated contents back to Lecturerdata.txt
                BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(stringBuilder.toString());
            }

            // Write a new record into secondMarker.txt
            File secondMarkerFile = new File("secondMarker.txt");
            try (BufferedWriter secondMarkerWriter = new BufferedWriter(new FileWriter(secondMarkerFile, true))) {
                String secondMarkerLine = studentID + ", " + project + ", " + lecturerName + ", Pending";
                secondMarkerWriter.write(secondMarkerLine);
                secondMarkerWriter.newLine();
            }

            JOptionPane.showMessageDialog(null, "Second marker assigned successfully.");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProjectManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ProjectManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //method to allot assessment type to student by individual
    public static void allot_student_individual(String individual, String assessment, String supervisor){
        // Define the file
        File file = new File("ReportDetails.txt");
        LocalDate nowdate = LocalDate.now();
        // Example start date and status
        String assignDate = nowdate.toString(); 
        String endDate = " "; // End date could be empty or set as needed
        String status = "Not Submitted"; 

        // Create a new line with the student details
        String newReport = individual + ", " + assignDate + ", " + endDate + ", " + assessment + ", " + status + ", " + supervisor;
        String newResult = individual + ", " + assessment + ", " + " " + ", " + " " + ", " + " " + ", " + " ";
        // Open the file in append mode and write the new line
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(newReport);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while writing to the file.");
        }
        File file2 = new File("Result.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file2, true))) {
            writer.write(newResult);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while writing to the file.");
        }
    }
    
    //method to allot assessment type to student by intake
    public static void allot_student_intake(String intake, String assessment, String supervisor){
        LocalDate nowDate = LocalDate.now();
        String assignDate = nowDate.toString();
        String endDate = " ";
        String status = "Not Submitted";

        try (BufferedReader reader = new BufferedReader(new FileReader("Studentdata.txt"))) {
            String line;
            boolean intakeFound = false;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", ");
                if (data.length == 5 && data[4].equals(intake)) {
                    intakeFound = true;
                    String tpNumber = data[1];

                    // Create new lines with the student details
                    String newReport = tpNumber + ", " + assignDate + ", " + endDate + ", " + assessment + ", " + status + ", " + supervisor;
                    String newResult = tpNumber + ", " + assessment + ", " + " " + ", " + " " + ", " + " " + ", " + " ";

                    // Write to ReportDetails.txt
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("ReportDetails.txt", true))) {
                        writer.write(newReport);
                        writer.newLine();
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null, "An error occurred while writing to ReportDetails.txt.");
                    }

                    // Write to Result.txt
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("Result.txt", true))) {
                        writer.write(newResult);
                        writer.newLine();
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null, "An error occurred while writing to Result.txt.");
                    }
                }
            }
            if (!intakeFound) {
                JOptionPane.showMessageDialog(null, "Data not found for intake: " + intake);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while reading Studentdata.txt.");
        }
    }
    
    //method to add item to array
    public static String[] addXY(int n, String arr[], String x, String y) 
    {  
        int i;
        String newarr[] = new String[n + 2]; 
        for (i = 0; i < n+1; i++) {
           newarr[i] = arr[i]; 
        } 
        newarr[n] = x; 
        newarr[n+1] = y;
        return newarr; 
    } 
    
    public static void replaceTextInFile(String filePath, String searchString, String replacement) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.replace(searchString, replacement);
                stringBuilder.append(line).append("\n");
            }
            reader.close();

            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            writer.write(stringBuilder.toString());
            writer.close();

            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    public void pmViewStatus(JRadioButton rbIntake, JRadioButton rbIndividual, JComboBox cbIntake, JComboBox cbIndividual, JTable statusTable){
        Set<String> tpNum = new HashSet<>();
        String filePath = "ReportDetails.txt";
        String[] columnNames = {"TP Number", "Intake", "Assign Date", "Submission Date", "Assessment Type", "Submission Status", "Lecturer", "Marks"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        // Collect all relevant TP Numbers based on intake if rbIntake is selected
        if (rbIntake.isSelected()) {
            String intake = cbIntake.getSelectedItem().toString();
            try (BufferedReader br = new BufferedReader(new FileReader("Studentdata.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] details = line.split(", ");
                    if (intake.equals(details[4])) {
                        tpNum.add(details[1]);
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            }
        }
        // Process the ReportDetails.txt file once
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(", ");
                boolean addRow = false;
                String tpNumber = data[0];
                String intake = "individual";  // default intake for individual case
                
                // Determine if row should be added based on selected option
                if (rbIntake.isSelected()) {
                    if (tpNum.contains(tpNumber)) {
                        intake = cbIntake.getSelectedItem().toString();
                        addRow = true;
                    }
                } else if (rbIndividual.isSelected()) {
                    String selectedTPNum = cbIndividual.getSelectedItem().toString();
                    if (selectedTPNum.equals(tpNumber)) {
                        addRow = true;
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select option (Intake/Individual).");
                    break;
                }
                
                if (addRow) {
                    // Fetch marks for this TP Number from Result.txt
                    String searchmarks = ProjectManager.parseFile("Result.txt", tpNumber);
                    String[] Marks = searchmarks.split(", ");
                    String[] rowData = {tpNumber, intake, data[1], data[2], data[3], data[4], data[5], Marks[4]};
                    tableModel.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        // Set the model to the table
        statusTable.setModel(tableModel);
    }
    
    //method to search data in file
    public static String parseFile(String fileName,String searchStr) throws FileNotFoundException{
        Scanner scan = new Scanner(new File(fileName));
        while(scan.hasNext()){
            String line = scan.nextLine();
            if(line.contains(searchStr)){
                return (line);
            }
        }
        return null;
    }
    
    public static String parseFile(String fileName, String searchStr, String searchStr2) throws FileNotFoundException{
        Scanner scan = new Scanner(new File(fileName));
        while(scan.hasNext()){
            String line = scan.nextLine();
            if(line.contains(searchStr) && line.contains(searchStr2)){
                return (line);
            }
        }
        return null;
    }
}
