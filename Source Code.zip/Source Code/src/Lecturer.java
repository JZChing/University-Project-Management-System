
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


class Lecturer extends User{
    //properties
    private static String additionalRole;
    private static String AssessmentType;
    
    //constructors
    public Lecturer(String password, String fullname, String id, String role, String additionalRole, String AssessmentType){
        super(password, fullname, id, role);
        Lecturer.additionalRole = additionalRole;
        Lecturer.AssessmentType = AssessmentType;
    }
    
    public Lecturer(){
        
    }

    public static String getAdditionalRole() {
        return additionalRole;
    }

    public static void setAdditionalRole(String additionalRole) {
        Lecturer.additionalRole = additionalRole;
    }

    public static String getAssessmentType() {
        return AssessmentType;
    }

    public static void setAssessmentType(String AssessmentType) {
        Lecturer.AssessmentType = AssessmentType;
    }
    
    
    //methods
    
    @Override
    public void ViewProfile(JTextField fullnameText,JTextField idText,JTextField additionalRoleText,JTextField passwordText,JTextField roleText) {
        String Fullname = Session.getFullname();
        String Id = Session.getId();
        String Password = Session.getPassword();
        String AdditionalRole = Lecturer.getAdditionalRole();
        String Role = Session.getRole();
        
        fullnameText.setText(Fullname);
        idText.setText(Id);
        additionalRoleText.setText(AdditionalRole);
        passwordText.setText(Password);
        roleText.setText(Role);
    }
    
    private void updatePresentationStatusFile(String tpnum, String date, String time, String status, String assessmentType) throws FileNotFoundException, IOException {  
        List<String> presentLines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Presentation.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 5) {
                    if (parts[0].trim().equals(tpnum) && parts[1].trim().equals(date) && parts[2].trim().equals(time)) {
                        parts[4] = status;
                        presentLines.add(String.join(", ", parts));
                    } else if (parts[0].trim().equals(tpnum) && parts[5].trim().equals(assessmentType) && !parts[4].trim().equals("Accepted") && !"Rejected".equals(status)) {
                        parts[4] = "Rejected";
                        presentLines.add(String.join(", ", parts));
                    } else {
                        presentLines.add(line);
                    }
                } else {
                    presentLines.add(line);
                }
            }
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("Presentation.txt"))) {
            for (String updatedLine : presentLines) {
                bw.write(updatedLine);
                bw.newLine();
            }
        }
            
      
    }
    
    //update status of either reject or accept to file
    public void confirmPresentation(JComboBox selectedTPNum, JComboBox selectedDate, JComboBox selectedTime, JTable tablePresentation, String status) throws IOException{

        // Get the selected values from JComboBoxes
        String selectedTPNumValue = selectedTPNum.getSelectedItem().toString();
        String selectedDateValue = selectedDate.getSelectedItem().toString();
        String selectedTimeValue = selectedTime.getSelectedItem().toString();

        // Update the status of the presentation request in the table
        DefaultTableModel model = (DefaultTableModel) tablePresentation.getModel();
        String assessmentType = "";
        for (int i = 0; i < model.getRowCount(); i++) {
            String tpnum = (String) model.getValueAt(i, 0);
            String date = (String) model.getValueAt(i, 1);
            String time = (String) model.getValueAt(i, 2);
            String currentStatus = (String) model.getValueAt(i, 4);
            String currentAssessmentType = (String) model.getValueAt(i, 5);

            if (tpnum.equals(selectedTPNumValue) && date.equals(selectedDateValue) && time.equals(selectedTimeValue)) {
                model.setValueAt(status, i, 4); // Assuming status is in column 4
                assessmentType = currentAssessmentType;
            } else if (tpnum.equals(selectedTPNumValue) && currentAssessmentType.equals(assessmentType) && !currentStatus.equals("Accepted") && !"Rejected".equals(status)) {
                model.setValueAt("Rejected", i, 4); // Reject other presentations with same tpnum and assessment type
            }
        }

        // Update the status in the file
        updatePresentationStatusFile(selectedTPNumValue, selectedDateValue, selectedTimeValue, status, assessmentType);

        // Refresh the table to reflect the changes
        tablePresentation.repaint();
        
        
    }
    
    //update the grade of student assessment to result file and update the assessment status in reportdetails file
    public void saveGrade(JComboBox cbTPNum, JComboBox cbGrade, JComboBox cbAssessment, JTextField feedback){
        try {
            // Read and update Result.txt
            StringBuilder resultContent = new StringBuilder();
            boolean isUpdated = false;
            String selectedTpNum = cbTPNum.getSelectedItem().toString();
            String selectedAssessment = cbAssessment.getSelectedItem().toString();
            String lecturerRole = Lecturer.getAdditionalRole();
            String selectedGrade = cbGrade.getSelectedItem().toString();
            String feedbackText = feedback.getText();

            try (BufferedReader br = new BufferedReader(new FileReader("Result.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(", ");


                    if (parts.length >= 6 && parts[0].equals(selectedTpNum) && parts[1].equals(selectedAssessment)) {
                        if (!"second marker".equals(lecturerRole)) {
                            parts[2] = selectedGrade; // Update first grade
                            parts[5] = feedbackText;
                        } else {
                            parts[3] = selectedGrade; // Update second grade
                            if (!parts[2].isEmpty()) { // Ensure first grade is not empty before calculating final grade
                                double firstGrade = Double.parseDouble(parts[2]);
                                double secondGrade = Double.parseDouble(parts[3]);
                                double finalGrade = (firstGrade + secondGrade) / 2;
                                parts[4] = Double.toString(finalGrade);
                            }
                        }
                        line = String.join(", ", parts);
                        isUpdated = true;
                    }
                    resultContent.append(line).append(System.lineSeparator());
                }
            }

            if (isUpdated) {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter("Result.txt"))) {
                    bw.write(resultContent.toString());
                }
            } else {
                JOptionPane.showMessageDialog(null, "No matching record found in Result.txt.");
                return;
            }

            // Update status in ReportDetails.txt
            StringBuilder reportContent = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new FileReader("ReportDetails.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(", ");
                    for (int i = 0; i < parts.length; i++) {
                        parts[i] = parts[i].trim();
                    }
                    if (parts.length >= 6 && parts[0].equals(cbTPNum.getSelectedItem().toString()) && parts[3].equals(cbAssessment.getSelectedItem().toString())) {
                        if (parts[4].equals("Waiting for grade")) {
                            parts[4] = "Graded";
                        }
                        line = String.join(", ", parts);
                    }
                    reportContent.append(line).append(System.lineSeparator());
                }
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter("ReportDetails.txt"))) {
                bw.write(reportContent.toString());
            }

            JOptionPane.showMessageDialog(null, "Grades updated successfully.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while updating the grades.");
        }
    
    }
    
    public void ViewSecondMarkerAcceptance(JTable tableMarker){  //load second marker file data to table
        // Read the file data
        List<String[]> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("secondMarker.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Split the line by comma and trim whitespace
                String[] parts = line.split(",");
                for (int i = 0; i < parts.length; i++) {
                    parts[i] = parts[i].trim();
                }
                data.add(parts);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        
        try {
            // Get the table model
            DefaultTableModel model = (DefaultTableModel)tableMarker.getModel();
        
            // Clear the existing table data
            model.setRowCount(0);
        
            for (String[] row : data) {
            // Add each row of data to the table model
                model.addRow(row);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }
    
    //update the second marker file status to accepted or rejected. If accepted update additional role of lecturer to second marker
    public void confirmSecondMarker(JTable markerAcceptance, JComboBox cbTPNum, JComboBox cbAssessment, String status){
        String tpNumSelected = cbTPNum.getSelectedItem().toString();
        String assessmentSelected = cbAssessment.getSelectedItem().toString();
        
        DefaultTableModel model = (DefaultTableModel) markerAcceptance.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            String tpnum = (String) model.getValueAt(i, 0);
            String assessment = (String) model.getValueAt(i, 1);
            String secondMarker = (String) model.getValueAt(i, 2);
            if (tpnum.equals(tpNumSelected) && assessment.equals(assessmentSelected) && secondMarker.equals(Session.getFullname())) {
                model.setValueAt(status, i, 3); // Assuming status is in column 4
                break; // No need to continue searching
            }
        }

        try {
            // Read the second marker file
            List<String> lines = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader("secondMarker.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(", ");
                    if (parts.length >= 4 && parts[0].trim().equals(tpNumSelected) && parts[1].trim().equals(assessmentSelected)) {
                        parts[3] = status;  // Update status to "Accepted"
                    }
                    lines.add(String.join(", ", parts));
                }
            }

            // Write the updated lines back to the file
            try (BufferedWriter bw = new BufferedWriter(new FileWriter("secondMarker.txt"))) {
                for (String updatedLine : lines) {
                    bw.write(updatedLine);
                    bw.newLine();
                }
            }
            
            if ("Accepted".equals(status)){
                assignSecondMarker(Session.getId(), assessmentSelected);
            }
            

            JOptionPane.showMessageDialog(null, "Second marker status updated successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    //this method will be used in the confirm second marker method to update lecturer data file additional role
    private void assignSecondMarker(String lecturerID, String project) {
        try {
            File file = new File("Lecturerdata.txt");
            StringBuilder stringBuilder;
            
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                stringBuilder = new StringBuilder();
                String line;
                // Search for the lecturer ID and update the line if found
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(", ");
                    if (parts.length >= 2 && parts[1].equals(lecturerID)) {
                        // Update the line with the new role and project
                        parts[4] = "second marker";
                        parts[5] = project;
                        line = String.join(", ", parts);
                    }
                    stringBuilder.append(line).append(System.lineSeparator());
                }
            }

            try ( // Write the updated contents back to Lecturerdata.txt
                BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(stringBuilder.toString());
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }   
    
    private List<String[]> loadDataFromFile(String filepath) throws IOException {
        List<String[]> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                for (int i = 0; i < parts.length; i++) {
                    parts[i] = parts[i].trim();
                }
                data.add(parts);
            }
        }
        return data;
    }
    
    //load assigned supervisees data to table, asssigned by PM
    public void loadAssignedSupervisees(String lecturerFile, String reportFile, String studentFile, JTable assignedSuperviseesTable) {
        try {
            List<String[]> reportDetails = loadDataFromFile(reportFile);
            List<String[]> students = loadDataFromFile(studentFile);

            String loggedInLecturer = Session.getFullname(); 
            String lecturerAssessmentType = Lecturer.AssessmentType;

            // Find matching TP numbers for the given lecturer's assessment type
            List<String> superviseeTpnums = new ArrayList<>();
            for (String[] report : reportDetails) {
                if (report[3].equals(lecturerAssessmentType) && report[5].equals(loggedInLecturer)) {
                    superviseeTpnums.add(report[0]);
                }
            }

            // Find students with matching TP numbers
            List<String[]> supervisees = new ArrayList<>();
            for (String[] student : students) {
                if (superviseeTpnums.contains(student[1])) {
                    supervisees.add(student);
                }
            }

            // Populate JTable with supervisees
            DefaultTableModel model = (DefaultTableModel) assignedSuperviseesTable.getModel();
            model.setRowCount(0); // Clear existing rows

            for (String[] supervisee : supervisees) {
                model.addRow(new Object[]{supervisee[0], supervisee[1], supervisee[4]});
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    //load the presentation data and report data of supervisee to table
    public void viewSuperviseeDashboard(JTable table){
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0); // Clear existing rows
        try {
            Report report = new Report();
            Presentation presentation = new Presentation();
            // Load data from files
            List<String[]> reportDetails = report.readReportDetails("ReportDetails.txt");
            List<String[]> presentationDetails = presentation.readPresentationDetails("Presentation.txt");
            Map<String, String> studentNames = presentation.readStudentNames("Studentdata.txt");

            // Process and merge data
            for (String[] reportDetail : reportDetails) {
                String tpNum = reportDetail[0];
                String assessmentType = reportDetail[3];
                String reportStatus = reportDetail[4];
                String studentName = studentNames.get(tpNum);
                String presentationStatus = presentation.getPresentationStatus(tpNum, assessmentType, presentationDetails);

                // Add row to the table model
                tableModel.addRow(new Object[]{tpNum, studentName, assessmentType, reportStatus, presentationStatus});
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }
    
    //view only the presentation status of supervisee in table
    public void viewSuperviseeList(JTable superviseeList){
        List<String[]> presentationData = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Presentation.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                presentationData.add(parts);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }

        List<String[]> studentData = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Studentdata.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                studentData.add(parts);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }

        DefaultTableModel model = (DefaultTableModel) superviseeList.getModel();
        model.setRowCount(0); // Clear existing rows

        for (String[] presentation : presentationData) {
            String tpNumber = presentation[0];
            String lecturer = presentation[3];
            String status = presentation[4];
            String assessmentType = presentation[5]; // Get assessment type

            if (lecturer.equals(Session.getFullname())) {
                for (String[] student : studentData) {
                    if (student[1].equals(tpNumber)) {
                        String studentName = student[0];
                        model.addRow(new Object[]{tpNumber, studentName, status, assessmentType});
                    }
                }
            }
        }
    }
    
    //load all the feedbacks from students towards the logged in lecturer from Feedback.txt into table
    public void viewFeedback(JTable tbFeedback, String lecturerName){
        DefaultTableModel tableModel = (DefaultTableModel) tbFeedback.getModel();
        try (BufferedReader reader = new BufferedReader(new FileReader("Feedback.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line by comma to separate the name and feedback
                String[] parts = line.split(", ");
                // If the line contains at least two parts (name and feedback)
                if (parts.length >= 2 && parts[0].trim().equals(lecturerName)) {
                    // Add only the feedback for the logged-in lecturer to the table model
                    tableModel.addRow(new Object[]{parts[1]}); // parts[1] contains the feedback
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error occurred while reading feedbacks.");
        }
    }
    
    //load all the accepted presentation request by the logged in lecturer as the lecturer presentation timetable.
    public void viewPresentationTimetable(String lecturerName, JTable PresentationTimetable, JComboBox tpnum, JComboBox assessment) {
        DefaultTableModel tableModel = (DefaultTableModel) PresentationTimetable.getModel();
        List<String[]> filteredData = new ArrayList<>();
        String line;

        try (BufferedReader br = new BufferedReader(new FileReader("Presentation.txt"))) {
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length == 6 && parts[3].equalsIgnoreCase(lecturerName) && parts[4].equalsIgnoreCase("Accepted")) {
                    filteredData.add(new String[]{parts[0], parts[1], parts[2], parts[5]});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error occurred while reading Presentation.txt.");
        }

        // Populate table with filtered data
        for (String[] row : filteredData) {
            tableModel.addRow(row);
        }
        
        // Populate TP number combo box
        tpnum.removeAllItems();
        for (String[] row : filteredData) {
            String tpNumber = row[0];
            tpnum.addItem(tpNumber);
            
        }
        
        //Add listener to TP number combo box to filter assessment types
        tpnum.addActionListener(e -> {
            String selectedTpNumber = (String) tpnum.getSelectedItem();
            Presentation presentation = new Presentation();
            presentation.LoadAssessment(selectedTpNumber, assessment, filteredData);
        });

        // Optionally, load assessment types for the first TP number in the combo box
        if (tpnum.getItemCount() > 0) {
            tpnum.setSelectedIndex(0);
        }
    }
    
    //to update the present status of supervisees to presented to indicate they have done their presentation for the assigned assessment
    public void confirmPresentation(String filePath, String tpnum, String assessment){
        List<String> updatedLines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length == 6 && parts[0].equals(tpnum) && parts[5].equals(assessment) && parts[4].equalsIgnoreCase("Accepted")) {
                    parts[4] = "Presented"; // Update status to "Presented"
                }
                updatedLines.add(String.join(", ", parts));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error occurred:" + e.getMessage());
        }

        // Write updated lines back to the file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (String updatedLine : updatedLines) {
                bw.write(updatedLine);
                bw.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error occurred:" + e.getMessage());
        }
    }
}