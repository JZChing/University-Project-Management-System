
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PMAllocateStudent extends javax.swing.JFrame {

    /**
     * Creates new form ProjectManager_allocatestudent
     */
    public PMAllocateStudent() {
        initComponents();
        cbIntake.setEnabled(false);
        cbTPNum.setEnabled(false);
        
        
        
        showdetails();
        btnGroup.add(rbIntake);
        btnGroup.add(rbIndividual);
        
        
          
        typecb.addActionListener(e -> {
            String selectedAssessment = typecb.getSelectedItem().toString();
            lecturercb.removeAllItems();
            if (selectedAssessment != null) {
                fill(lecturercb, selectedAssessment);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGroup = new javax.swing.ButtonGroup();
        Headinglbl = new javax.swing.JLabel();
        AssessmentTypelbl = new javax.swing.JLabel();
        confirmbtn = new javax.swing.JButton();
        typecb = new javax.swing.JComboBox<>();
        Backbtn = new javax.swing.JButton();
        rbIntake = new javax.swing.JRadioButton();
        rbIndividual = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Studenttb = new javax.swing.JTable();
        Lecturerlbl = new javax.swing.JLabel();
        lecturercb = new javax.swing.JComboBox<>();
        cbIntake = new javax.swing.JComboBox<>();
        cbTPNum = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Headinglbl.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Headinglbl.setText("Allocate Project To Student");

        AssessmentTypelbl.setText("Assessment Type:");

        confirmbtn.setText("Confirm");
        confirmbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmbtnActionPerformed(evt);
            }
        });

        typecb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Internship", "Investigation  Reports", "CP1", "CP2", "RMCP", "FYP" }));

        Backbtn.setText("Back");
        Backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbtnActionPerformed(evt);
            }
        });

        rbIntake.setText("Intake");
        rbIntake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbIntakeActionPerformed(evt);
            }
        });

        rbIndividual.setText("Individual");
        rbIndividual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbIndividualActionPerformed(evt);
            }
        });

        Studenttb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Name", "TP Number", "Intake"
            }
        ));
        jScrollPane1.setViewportView(Studenttb);

        Lecturerlbl.setText("Supervisor:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(Headinglbl)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(confirmbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbIndividual, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbIntake, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AssessmentTypelbl)
                            .addComponent(Lecturerlbl))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(typecb, 0, 210, Short.MAX_VALUE)
                            .addComponent(lecturercb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbIntake, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbTPNum, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Headinglbl)
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbIntake)
                    .addComponent(cbIntake, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbIndividual)
                    .addComponent(cbTPNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(typecb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AssessmentTypelbl))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Lecturerlbl)
                    .addComponent(lecturercb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Backbtn))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confirmbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmbtnActionPerformed
        //method to check which option that choose from project manager and allot assessment type
        if (rbIntake.isSelected()){
            String intake = cbIntake.getSelectedItem().toString();
            String assessment = typecb.getSelectedItem().toString();
            String supervisor = lecturercb.getSelectedItem().toString();
            ProjectManager.allot_student_intake(intake, assessment, supervisor);
            JOptionPane.showMessageDialog(null, "Assessment Assigned");
        } else if (rbIndividual.isSelected()){
            String individual = cbTPNum.getSelectedItem().toString();
            String assessment = typecb.getSelectedItem().toString();
            String supervisor = lecturercb.getSelectedItem().toString();
            ProjectManager.allot_student_individual(individual, assessment, supervisor);
            JOptionPane.showMessageDialog(null, "Assessment Assigned");
        } else{
            JOptionPane.showMessageDialog(null, "Please select option(Intake/Individual).");
        }
    }//GEN-LAST:event_confirmbtnActionPerformed

    private void BackbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbtnActionPerformed
        // method go back to menu
        PMmenu pmds = new PMmenu();
        pmds.show();
        dispose();
    }//GEN-LAST:event_BackbtnActionPerformed

    private void rbIntakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbIntakeActionPerformed
        if (rbIntake.isSelected()){
            cbIntake.setEnabled(true);
            cbTPNum.setEnabled(false);
            
            Set<String> intakes = new HashSet<>();

            try (BufferedReader br = new BufferedReader(new FileReader("Studentdata.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] details = line.split(", ");
                    if (details.length == 5) {
                        String intake = details[4];
                        if (!intake.equals("individual")) {
                            intakes.add(intake);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            for (String intake : intakes) {
                cbIntake.addItem(intake);
            }
        }
    }//GEN-LAST:event_rbIntakeActionPerformed

    private void rbIndividualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbIndividualActionPerformed
        if (rbIndividual.isSelected()){
            cbTPNum.setEnabled(true);
            cbIntake.setEnabled(false);
            
            Set<String> tpNumbers = new HashSet<>();

            try (BufferedReader br = new BufferedReader(new FileReader("Studentdata.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] details = line.split(", ");
                    if (details.length >= 2 && details[4].equals("individual")) {
                        String tpNumber = details[1];
                        tpNumbers.add(tpNumber);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            for (String tpNumber : tpNumbers) {
                cbTPNum.addItem(tpNumber);
            }
        } 
    }//GEN-LAST:event_rbIndividualActionPerformed

    private void showdetails(){
        //method to show student report in the table
        String filePath = "Studentdata.txt";
        String[] columnNames = {"Name","TP Number","Intake"}; 
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        
        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(","); 
                String[] rowData = {data[0], data[1], data[4]}; 
                tableModel.addRow(rowData);
            }
            br.close();
            Studenttb.setModel(tableModel);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void fill(JComboBox<String> lecturer, String assessment){
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Lecturerdata.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", "); 
                if (data[4].equals("supervisor") && data[5].trim().equals(assessment)){
                   lecturer.addItem(data[0]);  
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PMAllocateStudent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AssessmentTypelbl;
    private javax.swing.JButton Backbtn;
    private javax.swing.JLabel Headinglbl;
    private javax.swing.JLabel Lecturerlbl;
    private javax.swing.JTable Studenttb;
    private javax.swing.ButtonGroup btnGroup;
    private javax.swing.JComboBox<String> cbIntake;
    private javax.swing.JComboBox<String> cbTPNum;
    private javax.swing.JButton confirmbtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> lecturercb;
    private javax.swing.JRadioButton rbIndividual;
    private javax.swing.JRadioButton rbIntake;
    private javax.swing.JComboBox<String> typecb;
    // End of variables declaration//GEN-END:variables
}
