/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;


public class Report {
    
    
    public Report(){
        
    }
    
   
    
    public void updateReportWriteDetails(String tpNumber, String reportDate, String reportStatus, String selectedAssessment) throws IOException {
        File file = new File("ReportDetails.txt");
        List<String> lines = new ArrayList<>();
        boolean isUpdated = false;
        // Read all lines from the file
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 0 && parts[0].equals(tpNumber) && parts.length > 3 && parts[3].equals(selectedAssessment)) {
                    // Update the report date and status if the tpNumber and assessment match
                    if (parts.length > 2) {
                        parts[2] = reportDate; // Update report date
                    }
                    if (parts.length > 5) {
                        parts[4] = "Waiting for grade"; // Update report status
                    }
                    line = String.join(", ", parts); // Reconstruct the line
                    isUpdated = true;
                }
                lines.add(line); // Add the line to the list
            }
        }

        // Write all lines back to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String updatedLine : lines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        }
    }     
        
    public void ReportWrite(String tpNumber, String assessmentType, String reportTitle, String reportContent)throws IOException{
        File file = new File("Report.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(tpNumber + ", ");
            writer.write(assessmentType + ", ");
            writer.write(reportTitle + ", ");
            writer.write(reportContent + "\n");
        }
    }
    public List<String[]> getSubmissionData(String tpNumber)throws IOException{
        List<String[]> submissionData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("ReportDetails.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", ");
                if (data[0].equals(tpNumber)) {
                    submissionData.add(data);
                }
            }
        }
        return submissionData;
    }
    
    public void loadAssessmentType(JComboBox<String> comboBox, String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 5 && "Not Submitted".equals(parts[4].trim()) && parts[0].trim().equals(Session.getId())) { 
                    model.addElement(parts[3].trim()); 
                }
            }
            comboBox.setModel(model); // Set the model to the combo box
        } catch (IOException ex) {
            System.err.println("Error reading file: " + ex.getMessage());
        }
    }
    
    public void loadLecturer(JComboBox<String> comboBox, String fileName, String selectedAssessment) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 5 && "Not Submitted".equals(parts[4].trim()) && parts.length > 3 && parts[3].equals(selectedAssessment) && parts[0].trim().equals(Session.getId())) {
                    model.addElement(parts[5].trim());
                }
            }
            comboBox.setModel(model); // Set the model to the combo box
        } catch (IOException ex) {
            System.err.println("Error reading file: " + ex.getMessage());
        }
    }
    
    public List<String[]> readReportDetails(String fileName) throws IOException {
        List<String[]> reportDetails = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = br.readLine()) != null) {
            reportDetails.add(line.split(", "));
        }
        br.close();
        return reportDetails;
    }
    
    
}

