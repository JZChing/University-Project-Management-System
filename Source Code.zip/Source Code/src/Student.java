

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */


public class Student extends User{
    private static String intake;

    // Constructor to create StudentProfile object
    public Student(String password, String fullname, String id, String role, String intake) {
        super(password, fullname, id, role);
        Student.intake = intake;
    }
    public Student(){
    }
    
    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getFullname() {
        return fullname;
    }

    @Override
    public String getId() {
        return id;
    }

    // Getters
    @Override
    public String getRole() {    
        return role;
    }

    public String getIntake() {
        return intake;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }


    @Override
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public void setRole(String role) {
        this.role = role;
    }
    
    

    public static void setIntake(String intake) {
        Student.intake = intake;
    }

    @Override
    public void ViewProfile(JTextField fullnameText,JTextField idText,JTextField intakeText,JTextField passwordText,JTextField roleText) {
        String Fullname = Session.getFullname();
        String Id = Session.getId();
        String Password = Session.getPassword();
        String Intake = this.getIntake();
        String Role = Session.getRole();
        
        fullnameText.setText(Fullname);
        idText.setText(Id);
        intakeText.setText(Intake);
        passwordText.setText(Password);
        roleText.setText(Role);
    }
    
    public void RequestPresentation(String tpNumber,String presentDate, String presentTime, String presentStatus, String selectedLecturer, String Assessment) throws IOException {
        File file = new File("Presentation.txt");

        // Open the file in append mode
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            // Create a new line with the presentation details
            String newLine = tpNumber + ", " + presentDate + ", " + presentTime + ", " + selectedLecturer + ", " + presentStatus + ", " + Assessment;

            // Write the new line to the file
            writer.write(newLine);
            writer.newLine();
        }
    }
    
    public void submitReport(JComboBox assessmentTypecb, JTextField titleTxt, JTextArea contentTxt){
        String assessmentType = assessmentTypecb.getSelectedItem().toString();
        String title = titleTxt.getText();
        String content = contentTxt.getText();
        String tpNumber = Session.getId();
        String reportDate = LocalDate.now().toString();
        String reportStatus = "Waiting for grade";
        
        try {
            if (!content.isEmpty() || !title.isEmpty()){
                // Write report details to "ReportDetails.txt"
                Report report = new Report();
                report.updateReportWriteDetails(tpNumber, reportDate, reportStatus, assessmentType);

                // Write report content to "Report.txt"
                report.ReportWrite(tpNumber, assessmentType, title, content);

                // Display a success message
                JOptionPane.showMessageDialog(null, "Report submitted successfully.");

                // Clear input fields after submission
                titleTxt.setText("");
                contentTxt.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Please ensure title or content is not empty before submission.");
            }
        } catch (IOException ex) {
            // Handle any IOException that occurs during file writing
            JOptionPane.showMessageDialog(null, "Error occurred while submitting report: " + ex.getMessage());
        }
    }
    
    public void viewSubmissionStatus(JTable submissionTb ,String tpNumber) {    
        Report report = new Report();
        try {
            List<String[]> reportData = report.getSubmissionData(tpNumber);
        
            DefaultTableModel model = (DefaultTableModel)submissionTb.getModel();
        
            model.setRowCount(0);
        
            for (String[] data : reportData) {
                model.addRow(data);
            }
        } catch (IOException ex) {
            System.err.println("Error reading presentation data: " + ex.getMessage());
        }
    }
    
    public void checkResult(JTable resultTb ,String tpNumber) {    
        Result resultObject = new Result();
        try {
            List<String[]> resultData = resultObject.getResultData(tpNumber);
        
            // Get the table model
            DefaultTableModel model = (DefaultTableModel)resultTb.getModel();
        
            // Clear the existing table data
            model.setRowCount(0);
        
            for (String[] data : resultData) {
            // Add each row of data to the table model
                
                model.addRow(data);  
                
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error reading presentation data: " + ex.getMessage());
        }
    }
    
    public void submitFeedback(String lecturerName, String feedback) {
        try (FileWriter writer = new FileWriter("Feedback.txt", true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer)) {
            if (!feedback.isEmpty()) {
                // Format: LecturerName: Feedback
                bufferedWriter.write(lecturerName + ", " + feedback);
                bufferedWriter.newLine();
                JOptionPane.showMessageDialog(null, "Feedback submitted");
            } else {
                JOptionPane.showMessageDialog(null, "Please ensure feedback is not empty when submitted"); 
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error occurred while saving feedback. Please try again later.");
        }

    }
   

}