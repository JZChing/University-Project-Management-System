
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class PMViewStatus extends javax.swing.JFrame {

    /**
     * Creates new form ProjectManager_view status
     */
    public PMViewStatus() {
        initComponents();
        btnGroup.add(rbIntake);
        btnGroup.add(rbIndividual);
        
        
        try (BufferedReader reader = new BufferedReader(new FileReader("Report.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                cbTPNum.addItem(parts[0].trim());
                cbAssessment.addItem(parts[1].trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGroup = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        statusTable = new javax.swing.JTable();
        Backbtn = new javax.swing.JButton();
        Filterbtn = new javax.swing.JButton();
        rbIntake = new javax.swing.JRadioButton();
        rbIndividual = new javax.swing.JRadioButton();
        Tittletxt = new javax.swing.JLabel();
        TPlbl = new javax.swing.JLabel();
        Showbtn = new javax.swing.JButton();
        heading = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        Reporttxt = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        cbIntake = new javax.swing.JComboBox<>();
        cbIndividual = new javax.swing.JComboBox<>();
        cbTPNum = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cbAssessment = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        statusTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "TP number", "Intake", "Assign Date", "Submission Date", "Assessment Type", "Status", "Lecturer", "Marks"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(statusTable);

        Backbtn.setText("Back");
        Backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbtnActionPerformed(evt);
            }
        });

        Filterbtn.setText("Filter");
        Filterbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FilterbtnActionPerformed(evt);
            }
        });

        rbIntake.setText("Intake");
        rbIntake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbIntakeActionPerformed(evt);
            }
        });

        rbIndividual.setText("Individual");
        rbIndividual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbIndividualActionPerformed(evt);
            }
        });

        Tittletxt.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Tittletxt.setText("Status Table");

        TPlbl.setText("TP Number:");

        Showbtn.setText("Show");
        Showbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowbtnActionPerformed(evt);
            }
        });

        heading.setText("Student Report");

        Reporttxt.setColumns(20);
        Reporttxt.setRows(5);
        jScrollPane2.setViewportView(Reporttxt);

        jScrollPane3.setViewportView(jScrollPane2);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("View Student Report");

        jLabel2.setText("Assessment Type:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(heading)
                    .addComponent(Tittletxt)
                    .addComponent(Backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rbIntake, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbIntake, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(TPlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbTPNum, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(jLabel2)))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(rbIndividual, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbAssessment, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbIndividual, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Showbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(77, 77, 77)
                        .addComponent(Filterbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(Tittletxt)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbIntake)
                    .addComponent(rbIndividual)
                    .addComponent(Filterbtn)
                    .addComponent(cbIntake, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbIndividual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TPlbl)
                    .addComponent(Showbtn)
                    .addComponent(cbTPNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(cbAssessment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(heading)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Backbtn)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbtnActionPerformed
        // method to go back menu
        PMmenu pmds = new PMmenu();
        pmds.show();
        dispose();
    }//GEN-LAST:event_BackbtnActionPerformed

    private void FilterbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FilterbtnActionPerformed
        // method to follow selected option and display student data in the table
        ProjectManager pm = new ProjectManager();
        pm.pmViewStatus(rbIntake, rbIndividual, cbIntake, cbIndividual, statusTable);
    }//GEN-LAST:event_FilterbtnActionPerformed

    private void rbIntakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbIntakeActionPerformed
        if (rbIntake.isSelected()){
            cbIntake.setEnabled(true);
            cbIndividual.setEnabled(false);
            
            Set<String> intakes = new HashSet<>();

            try (BufferedReader br = new BufferedReader(new FileReader("Studentdata.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] details = line.split(", ");
                    if (details.length == 5) {
                        String intake = details[4];
                        if (!intake.equals("individual")) {
                            intakes.add(intake);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            for (String intake : intakes) {
                cbIntake.addItem(intake);
            }
        }
    }//GEN-LAST:event_rbIntakeActionPerformed

    private void rbIndividualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbIndividualActionPerformed
        if (rbIndividual.isSelected()){
            cbIndividual.setEnabled(true);
            cbIntake.setEnabled(false);
            
            Set<String> tpNumbers = new HashSet<>();

            try (BufferedReader br = new BufferedReader(new FileReader("Studentdata.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] details = line.split(", ");
                    if (details.length >= 2) {
                        String tpNumber = details[1];
                        tpNumbers.add(tpNumber);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            for (String tpNumber : tpNumbers) {
                cbIndividual.addItem(tpNumber);
            }
        } 
    }//GEN-LAST:event_rbIndividualActionPerformed

    private void ShowbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowbtnActionPerformed
        // method to show student project in the text area
        String TP = cbTPNum.getSelectedItem().toString();
        String AssessmentType = cbAssessment.getSelectedItem().toString();
        try {
            String data = ProjectManager.parseFile("Report.txt", TP, AssessmentType);
            String[] List = data.split(", ");
            Reporttxt.setText(List[3]);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PMViewStatus.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_ShowbtnActionPerformed

    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PMViewStatus().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Backbtn;
    private javax.swing.JButton Filterbtn;
    private javax.swing.JTextArea Reporttxt;
    private javax.swing.JButton Showbtn;
    private javax.swing.JLabel TPlbl;
    private javax.swing.JLabel Tittletxt;
    private javax.swing.ButtonGroup btnGroup;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbAssessment;
    private javax.swing.JComboBox<String> cbIndividual;
    private javax.swing.JComboBox<String> cbIntake;
    private javax.swing.JComboBox<String> cbTPNum;
    private javax.swing.JLabel heading;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JRadioButton rbIndividual;
    private javax.swing.JRadioButton rbIntake;
    private javax.swing.JTable statusTable;
    // End of variables declaration//GEN-END:variables
}
