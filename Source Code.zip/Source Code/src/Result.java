
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Result {
    private String tpNumber;
    private String assessmentType;
    private String finalResult;
    
    public Result(){
        
    }
    
    public Result(String tpNumber, String assessmentType, String finalResult){
        this.tpNumber = tpNumber;
        this.assessmentType = assessmentType;
        this.finalResult = finalResult;
    }
    public List<String[]> getResultData(String tpNumber) throws IOException {
        List<String[]> resultData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Result.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", ");
                if (data.length > 5 && data[0].equals(tpNumber)) {
                    resultData.add(new String[]{data[0], data[1], data[4], data[5]});
                }
            }
        }
        return resultData;
    }
    
}
