
import javax.swing.JTextField;

public abstract class User {
    protected String password, username, fullname, id, role;
    
    //Constructor
    public User(String password, String fullname, String id, String role) {
        this.password = password;
        this.fullname = fullname;
        this.id = id;
        this.role = role;
    }
    
    
    public User(){
        
    }
    
    //Getter
    public String getPassword(){
        return password;
    }
    
    public String getFullname(){
        return fullname;
    }
    
    public String getId(){
        return id;
    }
    
    public String getRole(){
        return role;
    }
    
    //Setter
    public void setPassword(String password){
        this.password = password;
    }
    
    public void setFullname(String fullname){
        this.fullname = fullname;
    }
    
    public void setId(String id){
        this.id = id;
    }
    
    public void setRole(String role){
        this.role = role;
    }
    
    public void ViewProfile(JTextField fullnameText, JTextField idText, JTextField passwordText, JTextField roleText, JTextField additional){
        String Fullname = Session.getFullname();
        String Id = Session.getId();
        String Password = Session.getPassword();
        String Role = Session.getRole();
        
        fullnameText.setText(Fullname);
        idText.setText(Id);
        passwordText.setText(Password);
        roleText.setText(Role);
    }
}