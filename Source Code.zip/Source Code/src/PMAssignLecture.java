
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class PMAssignLecture extends javax.swing.JFrame {

    /**
     * Creates new form ProjectManager_assignlecture
     */
    public PMAssignLecture() {
        initComponents();
        
        fillstudent(cbStudent);
        filllecturer(cbLecturerID);
        btnGroup.add(ShowAllrb);
        btnGroup.add(ShowLessrb);
        cbStudent.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGroup = new javax.swing.ButtonGroup();
        Headinglbl = new javax.swing.JLabel();
        Confirmbtn = new javax.swing.JButton();
        Backbtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Lecturertb = new javax.swing.JTable();
        ShowAllrb = new javax.swing.JRadioButton();
        ShowLessrb = new javax.swing.JRadioButton();
        AssessmentTypelbl = new javax.swing.JLabel();
        cbAssessment = new javax.swing.JComboBox<>();
        Studentlbl = new javax.swing.JLabel();
        cbStudent = new javax.swing.JComboBox<>();
        cbLecturerID = new javax.swing.JComboBox<>();
        cbRole = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Headinglbl.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Headinglbl.setText("Assign supervisor and second markers");

        Confirmbtn.setText("Confirm");
        Confirmbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmbtnActionPerformed(evt);
            }
        });

        Backbtn.setText("Back");
        Backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbtnActionPerformed(evt);
            }
        });

        Lecturertb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Lecturer", "ID", "Role"
            }
        ));
        jScrollPane1.setViewportView(Lecturertb);

        ShowAllrb.setText("Show all lecturer");
        ShowAllrb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowAllrbActionPerformed(evt);
            }
        });

        ShowLessrb.setText("Show unassigned lecturer");
        ShowLessrb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowLessrbActionPerformed(evt);
            }
        });

        AssessmentTypelbl.setText("Assessment Type:");

        cbAssessment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Internship", "Investigation  Reports", "CP1", "CP2", "RMCP", "FYP" }));

        Studentlbl.setText("Student:");

        cbRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "supervisor", "second marker" }));
        cbRole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRoleActionPerformed(evt);
            }
        });

        jLabel1.setText("Lecturer ID:");

        jLabel2.setText("Assign role:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ShowAllrb)
                                .addGap(18, 18, 18)
                                .addComponent(ShowLessrb))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(231, 231, 231)
                                .addComponent(Confirmbtn))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Studentlbl)
                                .addGap(18, 18, 18)
                                .addComponent(cbStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(AssessmentTypelbl, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbAssessment, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(22, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbLecturerID, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(130, 130, 130)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(cbRole, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(Headinglbl))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(Headinglbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ShowAllrb)
                    .addComponent(ShowLessrb))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbLecturerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Studentlbl)
                    .addComponent(cbStudent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AssessmentTypelbl)
                    .addComponent(cbAssessment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Confirmbtn)
                    .addComponent(Backbtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ConfirmbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmbtnActionPerformed
        // method to check which option select by project manager and assign lecturer
        String lecturer = cbLecturerID.getSelectedItem().toString();
        String role = cbRole.getSelectedItem().toString();
        String project = cbAssessment.getSelectedItem().toString();
        String student = cbStudent.getSelectedItem().toString();
        if (role.equals("supervisor")){
            ProjectManager.assign_supervisor(lecturer,project);
            cbLecturerID.removeItem(lecturer);
        } else if (role.equals("second marker")){
            ProjectManager.assign_secondmarker(student,lecturer,project);
            cbLecturerID.removeItem(lecturer);
        } else{
            JOptionPane.showMessageDialog(null, "Please select option.");
        }
    }//GEN-LAST:event_ConfirmbtnActionPerformed

    private void BackbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbtnActionPerformed
        // method to go back menu
        PMmenu pmds = new PMmenu();
        pmds.show();
        dispose();
    }//GEN-LAST:event_BackbtnActionPerformed

    private void ShowAllrbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowAllrbActionPerformed
        // method to show all the registered lecturer
        String filePath = "Lecturerdata.txt";
        String[] columnNames = {"Lecturer","ID","Role"}; 
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        
        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(", "); 
                String[] rowData = {data[0], data[1], data[4]}; 
                tableModel.addRow(rowData);
            }
            br.close();
            Lecturertb.setModel(tableModel);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_ShowAllrbActionPerformed

    private void ShowLessrbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowLessrbActionPerformed
        // method to show the lecturer are haven't assign
        String filePath = "Lecturerdata.txt";
        String[] columnNames = {"Lecturer","ID","Role"}; 
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        
        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(", "); 
                if (data[4].equals(" ")){
                    String[] rowData = {data[0], data[1], data[4]}; 
                    tableModel.addRow(rowData);
                }
            }
            br.close();
            Lecturertb.setModel(tableModel);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_ShowLessrbActionPerformed

    private void cbRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRoleActionPerformed
        if ("supervisor".equals(cbRole.getSelectedItem().toString())){
            cbStudent.setEnabled(false);
        } else if ("second marker".equals(cbRole.getSelectedItem().toString())){
            cbStudent.setEnabled(true);
        }
    }//GEN-LAST:event_cbRoleActionPerformed

    public void fillstudent(JComboBox<String> comboBox){
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Studentdata.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", "); 
                comboBox.addItem(data[1]); 
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void filllecturer(JComboBox<String> comboBox){
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Lecturerdata.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", "); 
                if (data[4].equals(" ")){
                   comboBox.addItem(data[1]);  
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PMAssignLecture().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AssessmentTypelbl;
    private javax.swing.JButton Backbtn;
    private javax.swing.JButton Confirmbtn;
    private javax.swing.JLabel Headinglbl;
    private javax.swing.JTable Lecturertb;
    private javax.swing.JRadioButton ShowAllrb;
    private javax.swing.JRadioButton ShowLessrb;
    private javax.swing.JLabel Studentlbl;
    private javax.swing.ButtonGroup btnGroup;
    private javax.swing.JComboBox<String> cbAssessment;
    private javax.swing.JComboBox<String> cbLecturerID;
    private javax.swing.JComboBox<String> cbRole;
    private javax.swing.JComboBox<String> cbStudent;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
