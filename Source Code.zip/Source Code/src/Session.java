public class Session {
    private static String fullname;
    private static String id;
    private static String password;
    private static String role;
    private static String file;

    // Setter
    public static void setFullname(String fullname) {
        Session.fullname = fullname;
    }
    public static void setId(String id) {
        Session.id = id;
    }
    public static void setPassword(String password) {
        Session.password = password;
    }
    public static void setRole(String role) {
        Session.role = role;
    }
    public static void setFile(String file) {
        Session.file = file;
    }    
    

    //Getter
    public static String getFullname() {
        return fullname;
    }
    public static String getId() {
        return id;
    }
    public static String getPassword() {
        return password;
    }
    public static String getRole() {
        return role;
    }
    public static String getFile() {
        return file;
    }
    
    
}

