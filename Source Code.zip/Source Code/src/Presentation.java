/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Presentation {
    private String lecturerName;
    private String presentDate;
    private String presentTime;
    private String presentStatus;
    
    public Presentation(){
        
    }
        
    public Presentation(String lecturerName, String presentDate, String presentTime, String presentStatus) {
        this.lecturerName = lecturerName;
        this.presentDate = presentDate;
        this.presentTime = presentTime;
        this.presentStatus = presentStatus;
    }    
    
    public void LoadAssessment(String tpNumber, JComboBox assessmentTypeComboBox, List<String[]> filteredData) {
        assessmentTypeComboBox.removeAllItems();
        for (String[] row : filteredData) {
            if (row[0].equals(tpNumber)) {
                String assessmentType = row[3];
                assessmentTypeComboBox.addItem(assessmentType);
                
            }
        }
    }
    
    public void LoadAssessment(JComboBox cbAssessment, String tpNumber){
        File reportDetailsFile = new File("ReportDetails.txt");
        File presentationFile = new File("Presentation.txt");

        Set<String> assessments = new HashSet<>();
        Set<String> acceptedAssessments = new HashSet<>();

        // Read Reportdetails.txt to get assessments
        try (BufferedReader reader = new BufferedReader(new FileReader(reportDetailsFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 4 && parts[0].equals(tpNumber)) {
                    assessments.add(parts[3]); // Add assessment type
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Presentation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Presentation.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Read Presentation.txt to get accepted assessments
        try (BufferedReader reader = new BufferedReader(new FileReader(presentationFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 5 && parts[0].equals(tpNumber) && parts[4].trim().equals("Accepted")) {
                    acceptedAssessments.add(parts[5].trim()); // Add assessment type
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Presentation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Presentation.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Remove accepted assessments from all assessments
        assessments.removeAll(acceptedAssessments);

        // Populate combo box
        cbAssessment.removeAllItems(); // Clear existing items
        for (String assessment : assessments) {
            cbAssessment.addItem(assessment);
        }
    }
    
    public void loadLecturer(String tpNumber, JComboBox cbAssessment, JLabel lblLecturer){
        try (BufferedReader reader = new BufferedReader(new FileReader("ReportDetails.txt"))) {
           String line;
           while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
               
                String tpNum = parts[0].trim();
                String assessment = parts[3].trim();
                String lecturer = parts[5].trim();

                if (tpNum.equals(tpNumber) && assessment.equals(cbAssessment.getSelectedItem())) {
                    lblLecturer.setText(lecturer);
                    return; // Exit loop once found
                }
               
           }
           // If no match found
           lblLecturer.setText(" ");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error reading file");
        }
    }
    
    public boolean isValidDay(int day, String month) {
        // List of months with 30 days
        List<String> monthsWith30Days = Arrays.asList("April", "June", "September", "November");

        // Validate day based on month
        if ((day < 1 || day > 31) ||
            (monthsWith30Days.contains(month) && day > 30) ||
            (month.equals("February") && day > 29)) {
            return false; // Day is invalid
        }
        return true; // Day is valid
    }
    public boolean isValidTime(String time){
         String regex = "^(1[012]|0[1-9]):[0-5][0-9](\\s)?(?i)(am|pm)$";
         Pattern pattern = Pattern.compile(regex);
         Matcher matcher = pattern.matcher(time);
         return matcher.matches();
    }
    
    public List<String[]> getPresentationData(String tpNumber)throws IOException{
        List<String[]> presentationData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Presentation.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(", ");
                if (data[0].equals(tpNumber)) {
                    presentationData.add(data);
                }
            }
        }
        return presentationData;
    }
    public void populatePresentationTable(JTable PresentationTb ,String tpNumber) {    
        Presentation presentation = new Presentation();
        try {
            List<String[]> presentationData = presentation.getPresentationData(tpNumber);
        
            // Get the table model
            DefaultTableModel model = (DefaultTableModel)PresentationTb.getModel();
        
            // Clear the existing table data
            model.setRowCount(0);
        
            // Populate the table with the presentation data
            for (String[] data : presentationData) {
            // Add each row of data to the table model
                model.addRow(data);
            }
        } catch (IOException ex) {
            System.err.println("Error reading presentation data: " + ex.getMessage());
        }
    }
    
    public void loadPresentationRequestsForLecturer(JTable presentationRequest) {
         // Initialize the DefaultTableModel
        DefaultTableModel model = (DefaultTableModel) presentationRequest.getModel();
        model.setRowCount(0);
        List<String[]> presentationData = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Presentation.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                presentationData.add(parts);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        
        String loggedInLecturer = Session.getFullname();
        for (String[] presentation : presentationData) {
            String tpNumber = presentation[0];
            String date = presentation[1];
            String time = presentation[2];
            String lecturer = presentation[3].trim();
            String status = presentation[4].trim();
            String assessment = presentation[5];

            if (lecturer.equals(loggedInLecturer)) {
                if (status.equals("Pending")){
                model.addRow(new Object[]{tpNumber, date, time, lecturer, status, assessment});
                }
            }
        }
    }
    
    public List<String[]> readPresentationDetails(String fileName) throws IOException {
        List<String[]> presentationDetails = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                presentationDetails.add(line.split(", "));
            }
        }
        return presentationDetails;
    }
    
    public String getPresentationStatus(String tpNum, String assessmentType, List<String[]> presentationDetails) {
        for (String[] presentation : presentationDetails) {
            if (presentation[0].equals(tpNum) && presentation[5].equals(assessmentType)) {
                return presentation[4]; // Return the presentation status
            }
        }
        return "Not Requested"; // Default status if not found
    }
    
    public Map<String, String> readStudentNames(String filename) throws IOException {
        Map<String, String> studentNames = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 1) {
                    studentNames.put(parts[1], parts[0]); // Map TP number to student name
                }
            }
        }
        return studentNames;
    }
    
    
}
